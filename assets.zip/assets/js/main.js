/**
* Template Name: AYP - v1.0.0
* Author: Anggiyasti Y Putri
*/
$(document).ready(function(){
    boxRollovers()
    $("#card").flip({
        trigger: 'manual'
    })
})


function boxRollovers() {

  // global vars
  $selector   = $(".theme-ayp-card");
  var XAngle  = 0;
  var YAngle  = 0;
  var Z       = 0;
  var touch   = 'ontouchstart' in document.documentElement;

  if( touch ) {

      // listen to device motion
      window.addEventListener('devicemotion', function(event){

          // load positions
          var accX = Math.round(event.accelerationIncludingGravity.x*10) / 10,
              accY = Math.round(event.accelerationIncludingGravity.y*10) / 10,
              xA = -(accX / 10) * settings.strength,
              yA = -(accY / 10) * settings.strength,
              newX = -(xA*2),
              newY = -(yA*2);
          
          // add roatation
          $selector.css({"transform":"perspective(525px) translateZ(" + Z + "px) rotateX(" + newX + "deg) rotateY(" + newY + "deg)","transition":"none","-webkit-transition":"none"});
      
      }, false);

  } else {
      
      $('.theme-main:not(.edit)').on("mousemove",function(e){

          // load positions
          var $this = $(this);
          var XRel = e.pageX - $this.offset().left;
          var YRel = e.pageY - $this.offset().top;
          var width = $this.width();
          var height = $this.height();
      
          YAngle = ( -(0.5 - (XRel / width)) * 40 ) / 2.66; 
          XAngle = ( (0.5 - (YRel / height)) * 40) / 2.66;
          
          // add roatation
          $selector.css({"transform":"perspective(525px) translateZ(" + Z + "px) rotateX(" + XAngle + "deg) rotateY(" + YAngle + "deg)","transition":"none","-webkit-transition":"none"});
  
      });
      
      $('.theme-main:not(.edit)').on("mouseleave",function(){

          // reset roatation
          $selector.css({"transform":"perspective(525px) translateZ(0) rotateX(0deg) rotateY(0deg)","transition":"all 150ms linear 0s","-webkit-transition":"all 150ms linear 0s"});

      });

  }
  
}

function contactForm() {
    $("#card").flip(true);
    $('#contact-form').show()
    $('#contact-form').css({
        'background': 'white',
        'display': true
    });
    $('.close-btn').show()
    $('#form input').not(":hidden").first().focus()

    
}

function nameCard() {
    $('.close-btn').hide()
    $('#contact-form').hide()
    $("#card").flip(false)
    $('#contact-form').css({
        'background': 'transparent',
    });

}

// receive data from contact form
$("#form").submit(function(e) {
    e.preventDefault();
    var email = $("[name=email]").val()
    var message = $("[name=message]").val()

    alert(`email : ${email} \nmessage: ${message}`)
})